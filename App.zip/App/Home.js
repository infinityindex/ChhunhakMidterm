import React, { Component } from 'react'
import { Text, View, SafeAreaView, Dimensions } from 'react-native'

export default class Home extends Component {
    render() {
        return (
            <SafeAreaView style={{ flex: 1, }}>
                <View style={{ flex: 1 }}>
                    <View style={{
                        flex: 1, 
                        backgroundColor: 'white',
                        width: 0,
                        height: 0,
                        backgroundColor: 'transparent',
                        borderStyle: 'solid',
                        borderLeftWidth: Dimensions.get('window').width,
                        borderTopWidth: Dimensions.get('window').width,
                        borderRightWidth: Dimensions.get('window').width,
                        borderLeftColor: 'blue',
                        borderRightColor: 'yellow',
                        borderTopColor: 'red',
                        // borderBottomColor: "red"
                    }}>
                        <Text>Hello world</Text>
                    </View>
                </View>
            </SafeAreaView>
        )
    }
}
